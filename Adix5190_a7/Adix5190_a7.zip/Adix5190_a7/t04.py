'''
[program description]

Author: Laith Adi 

ID: 170265190

Email: Adix5190@mylaurier.ca

__updated__ = "2018-11-16"

'''
from functions import common_ending
s1 = input('First string:')
s2 = input('Second string:')
common = common_ending(s1, s2)
print('Common ending: {}'.format(common))
