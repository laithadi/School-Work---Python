"""
------------------------------------------------------------------------
remove vowels from string
------------------------------------------------------------------------
Author: Jayvinder Singh, Laith Adi
ID:     181000220, 170265190
Email:  rsha0220@mylaurier.ca, adix5190@mylaurier.ca
__updated__ = "2018-11-08"
------------------------------------------------------------------------
"""


from functions import dsmvwl


s = input("Enter a string: ")
out = dsmvwl(s)
print(out)
